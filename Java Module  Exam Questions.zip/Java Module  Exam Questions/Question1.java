import java.util.*;
public class Question1
{
  public static void main(String args [])
  {
	   ArrayList<String> list=new ArrayList<String>();
	  list.add("Red");
	  list.add("Yellow");
	  list.add("Green");
	  list.add("Orange");
	  list.add("White");
	  System.out.println("ArrayList Element are:"+list);
	  
	  System.out.println("Now iterating ArrayList Element one by one using for loop And Printing Them");
	  for(int i=0;i<list.size();i++)
      {
		 System.out.println(list.get(i));   
	  }
	  
	  
  }
}