
class Grandparent {
	public void Print()
	{
		System.out.println("GrandFather name = Laxman");
		System.out.println("GrandMother = Janabai");
	}
}

class Parent extends Grandparent {
	public void Print()
	{
		super.Print();
		System.out.println("Father name = Wasudeo");
		System.out.println("Mother name = Rukhma");
	}
}

class Child extends Parent {
	public void Print()
	{
		super.Print();
		System.out.println("Child Name = Amol");
	}
}

public class Main {
	public static void main(String[] args)
	{
		Child c = new Child();
		c.Print();
	}
}
